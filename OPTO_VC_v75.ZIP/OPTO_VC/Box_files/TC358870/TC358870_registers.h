// Define to prevent recursive inclusion 
#ifndef __TC358870_H
#define __TC358870_H

//----------------------------------------	
//	�������� ��358870
#define  ChipRevID				0x0000	//	0x0047
#define  SysCtl						0x0002
#define  ConfCtl0					0x0004
#define  ConfCtl1					0x0006
#define  INTstatus				0x0014
#define  INTmask					0x0016	
#define  bank_TX0					0x0000
#define  bank_TX1					0x0200
	
#define  DSI_TX_CLKen 		0x0108
#define  DSI_TX_CLKsel 		0x010C
#define  MODEconfig	 			0x0110
#define  LANE_en		 			0x0118
#define  DSITX_START			0x011C
#define  LINE_init_cnt 		0x0120
#define  HSTX_to_cnt	 		0x0124
#define  FUNC_enable			0x0128
#define  DSI_tato_cnt 		0x0130
#define  PRESP_bta_cnt 		0x0134
#define  PRESP_lpr_cnt 		0x0138
#define  PRESP_lpw_cnt 		0x013C
#define  PRESP_hsr_cnt 		0x0140
#define  PRESP_hsw_cnt 		0x0144
#define  PR_to_cnt	 			0x0148
#define  LRX_H_to_cnt 		0x014C
#define  FUNC_mode	 			0x0150
#define  DSI_rx_vc_en 		0x0154
#define  IND_to_cnt	 			0x0158
#define  HSYNC_stop_cnt 	0x0168
#define  APF_vdelay_cnt 	0x0170
#define  DSI_TX_mode	 		0x017C
#define  DSI_HSYNC_width 	0x018C
#define  DSI_HBPR	 				0x0190
#define  RX_int_mask	 		0x01A4
#define  LPRX_thresh_cnt 	0x01C0
#define  APP_err_int_mask 0x0214
#define  RX_err_int_mask 	0x021C
#define  LPTX_int_mask 		0x0224
#define  LPTX_time_cnt 		0x0254
#define  TCK_header_cnt 	0x0258
#define  TCK_trail_cnt 		0x025C
#define  THS_header_cnt 	0x0260
#define  TWAKEUP_cnt	 		0x0264
#define  TCLK_post_cnt 		0x0268
#define  THS_trail_cnt 		0x026C
#define  HSTX_vreg_cnt 		0x0270
#define  HSTX_vreg_en 		0x0274
#define  BTA_cnt		 			0x0278 
#define  DPHY_txadjust 		0x027C
//#define  MIPI_PLL_ctrl 		0x02A0
//#define  MIPI_PLL_cnf 		0x02AC
#define	 MIPI_PLL_CTRL		0x02A0
#define	 MIPI_PLL_CONF    0x02AC
#define  DSI_TX_start 		0x011C	
#define  DSI_RX_header  	0x01BC	
#define  CMDsel		 				0x0500
#define  DCSCMD_Q	 				0x0504	
#define  STX0ctl		 			0x5000
#define	 STX0_WC					0x5008
#define  STX0fpx		 			0x500C
#define  STX1ctl		 			0x5080
#define  STX1_WC					0x5088
#define  PHYctl		 				0x8410
#define  PHYenb		 				0x8413
#define  APLLctl		 			0x84F0
#define  DDCIOctl	 				0x84F4	
#define  HDCPmode	 				0x8560
#define  PACKETintm	 			0x8514
#define  CBITintm	 				0x8515
#define  AUDIOintm	 			0x8516
#define  SYSstatus	 			0x8520	
#define  SYSint		 				0x8502
#define  SYSintm		 			0x8512	
#define  SYSfreq0_1	 			0x8540
#define  LOCKDETfreq0_1 	0x8630
#define  LOCKDETref1_2 		0x8631
#define  NCOf0mod	 				0x8670
#define  CSCsclk0_1	 			0x8A0C	
#define  VOUTsync0	 			0x8A02	
#define  DDCctl		 				0x8543
#define  HPDctl		 				0x8544
#define	 INIT_END					0x854A
#define  EDID_mode	 			0x85E0
#define  EDID_len1_2	 		0x85E3
#define  EDID_RAM	 				0x8C00	
#define  AUDautomute	 		0x8600
#define  AUDautocmd0	 		0x8602
#define  AUDautocmd1	 		0x8603
#define  AUDautocmd2	 		0x8604
#define  AUDbufinitstart 	0x8606
#define  AUDfsmute	 			0x8607
#define  AUDsdomode1	 		0x8652
#define  NCO48F0ad	 			0x8671
#define  NCO44F0ad	 			0x8675
#define  AUDmode		 			0x8680	
#define  INITend		 			0x854A
#define  VOUT_SYNC0 			0x8A02
//-------------------------------------


#endif //	__TC358870_H
