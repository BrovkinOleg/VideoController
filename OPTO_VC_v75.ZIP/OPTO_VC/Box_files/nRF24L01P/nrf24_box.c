//---------------------------------------------------
#include "nrf24_box.h"
#include "BNO080_box.h"
#include "string.h"
//---------------------------------------------------
/* NRF structure */
static nRF24L01P_structure nRF_str;
uint8_t Flag_Get_nRF;	//	��� ����� ������
MAIN_BUF_str Pult_nRF_buf;	//	�������� ����� �� ������
uint8_t Timer_pult_yes;	//	������ ���������� ������ ���. ������
//---------------------------------------------------
//-------------- function prototypes ----------------
void stop_5mks(void);
void csHigh(void);
void csLow(void);
void ceHigh(void);
void ceLow(void);
void clk_on(void);
void clk_off(void);
void BoxInitSPI1(void);
void Send_N_Bytes(uint8_t *ptr, uint8_t N);
uint8_t Send_SPI_Byte(uint8_t spi_out);
void Read_Bytes_From_nRF24(un char *Buf, un char N);
void Write_Bytes_To_nRF24(un char *Buf, un char N);
void CheckTransmit(void);
uint8_t Read_nRF24_Status(void);
void nRF24L01_Flush_TX(void);	//	������ ����� TX
void nRF24L01_Flush_RX(void);	//	������ ����� RX
uint8_t nRF24L01P_Init(uint8_t channel, uint8_t payload_size);


void nRF24L01P_WriteBit(uint8_t reg, uint8_t bit, uint8_t value);
uint8_t nRF24L01P_ReadBit(uint8_t reg, uint8_t bit);
uint8_t nRF24L01P_ReadRegister(uint8_t reg);
void nRF24L01P_ReadRegisterMulti(uint8_t reg, uint8_t* data, uint8_t count);
void nRF24L01P_WriteRegisterMulti(uint8_t reg, uint8_t *data, uint8_t count);
void nRF24L01P_SoftwareReset(void);
uint8_t nRF24L01P_RxFifoEmpty(void);

//---------------------------------------------------
//---------------------------------------------------
void stop_5mks(void)
{
	//uint16_t i;	
	//for (i=0; i<3; i++) ;
}
//---------------------------------------------------
//---------------------------------------------------
void csHigh(void)
{	
	GPIOB->BSRR |= 1<<6; //PB.6 := 1
}
//---------------------------------------------------
void csLow(void)
{
	GPIOB->BSRR = 1<<(6+16); //PB.6 := 0
}
//---------------------------------------------------
void ceHigh(void)
{
	GPIOB->BSRR = 1<<7; //PB.7 := 1
}
//---------------------------------------------------
void ceLow(void)
{
	GPIOB->BSRR = 1<<(7+16); //PB.7 := 0
}
//---------------------------------------------------
void clk_on(void)
{
	GPIOB->BSRR = 1<<3; //PB.3 := 1
}
//---------------------------------------------------
void clk_off(void)
{
	GPIOB->BSRR = 1<<(3+16); //PB.3 := 0
}
//---------------------------------------------------
//---------------------------------------------------
void BoxInitSPI1(void)
{
	SPI1->CR1 |= 1<<6;
}
//---------------------------------------------------
//	��������� ����� �� ������
void Box_Get_nRF_Packet(void)
{
	static uint8_t pult; // ����� ������			
	uint8_t A[32];
	CS_Low;	//	csLow();
	uint8_t d = Send_SPI_Byte(0x07);	//	������� ������ �������
	CS_High;	//	csHigh();
	if ((d & 0x40) == 0)
		return;
	CS_Low;	//	csLow();
	Send_SPI_Byte(0x61);	//	������� ������ ������
	//	�������� CRC, ���� ����������, - ���������
	Read_Bytes_From_nRF24(A,32);	
	
//	�������� ����������� ����� CRC	
	uint8_t _CRC, i;
	uint8_t *ptr = &A[0];	//&MAIN_buf.gamequat[0];
	for (i=0, _CRC=0; i<31; i++)
		_CRC += *(ptr+i);
	++pult;	//	��� ������� ��������� ������
	if (A[31] == _CRC)
	{		
		Pult_nRF_buf.step = pult;	//	����� ������ CRC->OK
		//__disable_irq();
		memcpy(&Pult_nRF_buf.gamequat[0],&A[0],32);	
		//__enable_irq();
	}
	CS_High;	//	csHigh();
	CS_Low;	//	csLow();
	Send_SPI_Byte(0x27);	//	������� ������ �����
	Send_SPI_Byte(0x40);	//	������
	CS_High;	//	csHigh();
}

//---------------------------------------------------
void Send_N_Bytes(uint8_t *ptr, uint8_t N)
{
	uint8_t i;
	GPIOB->ODR &= ~(1<<6);		//	CS := 0	
	stop_5mks();
	for (i=0; i<N; i++)
	{
		Send_SPI_Byte(*(ptr+i));
		stop_5mks();
	}
	GPIOB->ODR |= (1<<6);			//	CS := 1
}
//---------------------------------------------------
//	�������� (� ��������) ���� �� nRF24L01P
uint8_t Send_SPI_Byte(uint8_t spi_out)
{		
	un char i, spi_in, M;
	for (i=0, M=0x80, spi_in=0; i<8; i++)
	{					
		if (spi_out & M)
			MOSI_ON;	//	MOSI:=1
		else
			MOSI_OFF;	//	MOSI:=0
		
		M >>= 1;		//	shift maska M
		spi_in <<= 1;
		CLK_ON;	//	CLK := 1
		
		if ((GPIOB->IDR & (1<<4)) != 0)
			spi_in |= 0x01;
				
		CLK_OFF;	// CLK := 0		
	}
	return spi_in;
}

//-------------------------------------------------
void Write_Bytes_To_nRF24(un char *Buf, un char N)
{
	un char i;
	un char *b = Buf;
	for (i=0; i<N; i++)
		Send_SPI_Byte(*(b+i));
}
//-------------------------------------------------
void Read_Bytes_From_nRF24(un char *Buf, un char N)
{
	un char i;
	for (i=0; i<N; i++)
		Buf[i] = Send_SPI_Byte(0xFF);
}
//-------------------------------------------------
uint8_t Read_nRF24_Status(void)
{
	uint8_t D;
	csLow();
	D = Send_SPI_Byte(0xFF);
	csHigh();
	return D;
}
//-------------------------------------------------
void CheckTransmit(void)
{
	
	ceHigh();
	nRF24L01P_WriteRegister(nRF_CONFIG,0x02);
	HAL_Delay(2);
	nRF24L01P_WriteRegister(nRF_RF_SETUP,0xBE);
	nRF24L01P_WriteRegister(nRF_RF_CH,0);
	ceHigh();
}

//-------------------------------------------------
//	HAL_Delay(100);

//-------------------------------------------------
//-------------------------------------------------
//	������ ����� TX
void nRF24L01_Flush_TX(void)
{
	csLow();
	Send_SPI_Byte( NRF24L01_FLUSH_TX_MASK); 
	csHigh();
}
//---------------------------------------------------
//	������ ����� RX
void nRF24L01_Flush_RX(void)
{
	csLow();
	Send_SPI_Byte( NRF24L01_FLUSH_RX_MASK); 
	csHigh();
}
//---------------------------------------------------
//---------------------------------------------------
uint8_t nRF24L01P_Init(uint8_t channel, uint8_t payload_size) 
{
	/* Max payload is 32bytes */
	if (payload_size > 32) 	
		payload_size = 32;	
	
	/* Fill structure */
	nRF_str.Channel 		= !channel; /* Set channel to some different value for nRF24L01P_SetChannel() function */
	nRF_str.PayloadSize = payload_size;
	nRF_str.OutPwr 			= nRF24L01P_OutputPower_0dBm;
	nRF_str.DataRate 		= nRF24L01P_DataRate_2M;
	
	/* Reset nRF24L01+ to power on registers values */
	nRF24L01P_SoftwareReset();
	
	/* Channel select */
	nRF24L01P_SetChannel(channel);
	
	/* Set pipeline to max possible 32 bytes */
	nRF24L01P_WriteRegister(nRF_RX_PW_P0, nRF_str.PayloadSize); // Auto-ACK pipe
	nRF24L01P_WriteRegister(nRF_RX_PW_P1, nRF_str.PayloadSize); // Data payload pipe
	nRF24L01P_WriteRegister(nRF_RX_PW_P2, nRF_str.PayloadSize);
	nRF24L01P_WriteRegister(nRF_RX_PW_P3, nRF_str.PayloadSize);
	nRF24L01P_WriteRegister(nRF_RX_PW_P4, nRF_str.PayloadSize);
	nRF24L01P_WriteRegister(nRF_RX_PW_P5, nRF_str.PayloadSize);
	
	/* Set RF settings (2mbps, output power) */
	nRF24L01P_SetRF(nRF_str.DataRate, nRF_str.OutPwr);
	
	/* Config register */
	nRF24L01P_WriteRegister(nRF_CONFIG, 0x0C);	//	PWR_UP = OFF, RX/TX
	
	/* Disable auto-acknowledgment for all pipes */
	nRF24L01P_WriteRegister(nRF_EN_AA, 0x00);	//	(no ACK) 01h = 0x3F
	
	/* Enable RX addresses */
	nRF24L01P_WriteRegister(nRF_EN_RXADDR, 0x3F);	//	(all pipes enabled) 02h = 0x3F 

	/* Auto retransmit delay: 1000 (4x250) mks and Up to 15 retransmit trials */
	nRF24L01P_WriteRegister(nRF_SETUP_RETR, 0x00);	//	(no retransmit) 03h = 0x4F 
	
	/* Dynamic length configurations: No dynamic length */
	nRF24L01P_WriteRegister(nRF_DYNPD, 0x00);
	
	/* Clear FIFOs */
	NRF24L01_FLUSH_TX;
	NRF24L01_FLUSH_RX;
	
	/* Clear interrupts */
	NRF24L01_CLEAR_INTERRUPTS;
	
	/* Go to RX mode */
	//nRF24L01P_PowerUpRx();
	nRF24L01P_PowerUpTx();
	
	/* Return OK */
	return 1;
}
//---------------------------------------------------
void nRF24L01P_SetMyAddress(uint8_t *adr) 
{
	ceLow();
	nRF24L01P_WriteRegisterMulti(nRF_RX_ADDR_P1, adr, 5);
	ceHigh();
}
//---------------------------------------------------
void nRF24L01P_SetTxAddress(uint8_t *adr) 
{
	nRF24L01P_WriteRegisterMulti(nRF_RX_ADDR_P0, adr, 5);
	nRF24L01P_WriteRegisterMulti(nRF_TX_ADDR, adr, 5);
}
//---------------------------------------------------
void nRF24L01P_WriteBit(uint8_t reg, uint8_t bit, uint8_t value) 
{
	uint8_t tmp;
	/* Read register */
	tmp = nRF24L01P_ReadRegister(reg);
	/* Make operation */
	if (value) 
	{
		tmp |= 1 << bit;
	} 
	else 
	{
		tmp &= ~(1 << bit);
	}
	/* Write back */
	nRF24L01P_WriteRegister(reg, tmp);
}
//---------------------------------------------------
uint8_t nRF24L01P_ReadBit(uint8_t reg, uint8_t bit) 
{
	uint8_t tmp;
	tmp = nRF24L01P_ReadRegister(reg);
	if (!NRF24L01_CHECK_BIT(tmp, bit)) 
	{
		return 0;
	}
	return 1;
}
//---------------------------------------------------
uint8_t nRF24L01P_ReadRegister(uint8_t reg) 
{
	uint8_t value;
	csLow();
	Send_SPI_Byte( READ_MASK(reg));
	value = Send_SPI_Byte( NRF24L01_NOP_MASK);
	csHigh();
	
	return value;
}
//---------------------------------------------------
void nRF24L01P_ReadRegisterMulti(uint8_t reg, uint8_t* data, uint8_t count) 
{
	csLow();
	Send_SPI_Byte( READ_MASK(reg));
	Read_Bytes_From_nRF24(data, count);	
	csHigh();
}
//---------------------------------------------------
void nRF24L01P_WriteRegister(uint8_t reg, uint8_t value) 
{
	csLow();
	Send_SPI_Byte( WRITE_MASK(reg));
	Send_SPI_Byte( value);
	csHigh();
}
//---------------------------------------------------
void nRF24L01P_WriteRegisterMulti(uint8_t reg, uint8_t *data, uint8_t count) 
{
	csLow();
	Send_SPI_Byte( WRITE_MASK(reg));
	Write_Bytes_To_nRF24(data, count);
	csHigh();
}
//---------------------------------------------------
void nRF24L01P_PowerUpTx(void) 
{
	NRF24L01_CLEAR_INTERRUPTS;
	//	NRF24L01_CONFIG | (0 << NRF24L01_PRIM_RX) | (1 << NRF24L01_PWR_UP));
	nRF24L01P_WriteRegister(nRF_CONFIG, 0x02);
}
//---------------------------------------------------
void nRF24L01P_PowerUpRx(void) 
{
	/* Disable RX/TX mode */
	ceLow();
	/* Clear RX buffer */
	NRF24L01_FLUSH_RX;
	/* Clear interrupts */
	NRF24L01_CLEAR_INTERRUPTS;
	/* Setup RX mode */
	//	NRF24L01_CONFIG | 1 << NRF24L01_PWR_UP | 1 << NRF24L01_PRIM_RX);
	nRF24L01P_WriteRegister(nRF_CONFIG, 0x03);
	/* Start listening */
	ceHigh();
}
//---------------------------------------------------
void nRF24L01P_PowerDown(void) 
{
	ceLow();
	nRF24L01P_WriteBit(nRF_CONFIG, NRF24L01_PWR_UP, 1);
	ceHigh();
}
//---------------------------------------------------
void nRF24L01P_Transmit(uint8_t *data) 
{
	uint8_t count = nRF_str.PayloadSize;
	
// Chip enable put to low, disable it 
	ceLow();	
// Go to power up tx mode 
	nRF24L01P_PowerUpTx();	
// Clear TX FIFO from NRF24L01+ 
	NRF24L01_FLUSH_TX;
// Send payload to nRF24L01+ 
	csLow();
// Send write payload command 
	Send_SPI_Byte( NRF24L01_W_TX_PAYLOAD_MASK);
// Fill payload with data
	Write_Bytes_To_nRF24(data, count);
// Disable SPI 
	csHigh();
// Send data! 
	ceHigh();
}
//---------------------------------------------------
void nRF24L01P_GetData(uint8_t* data) 
{
// Pull down chip select 
	csLow();
// Send read payload command
	Send_SPI_Byte( NRF24L01_R_RX_PAYLOAD_MASK);
// Read payload 
	Read_Bytes_From_nRF24(data, nRF_str.PayloadSize);
// Pull up chip select 
	csHigh();	
// Reset status register, clear RX_DR interrupt flag 
	nRF24L01P_WriteRegister(nRF_STATUS, (1 << NRF24L01_RX_DR));
}
//---------------------------------------------------
uint8_t nRF24L01P_DataReady(void) 
{
	uint8_t status = nRF24L01P_GetStatus();
	
	if (NRF24L01_CHECK_BIT(status, NRF24L01_RX_DR)) 
	{
		return 1;
	}
	return !nRF24L01P_RxFifoEmpty();
}
//---------------------------------------------------
uint8_t nRF24L01P_RxFifoEmpty(void) 
{
	uint8_t reg = nRF24L01P_ReadRegister(nRF_FIFO_STATUS);
	return NRF24L01_CHECK_BIT(reg, NRF24L01_RX_EMPTY);
}
//---------------------------------------------------
uint8_t nRF24L01P_GetStatus(void) 
{
	uint8_t status;
	
	csLow();
	/* First received byte is always status register */
	status = Send_SPI_Byte( NRF24L01_NOP_MASK);
	/* Pull up chip select */
	csHigh();
	
	return status;
}
//---------------------------------------------------
nRF24L01P_Transmit_Status_t nRF24L01P_GetTransmissionStatus(void) 
{
	uint8_t status = nRF24L01P_GetStatus();
	if (NRF24L01_CHECK_BIT(status, NRF24L01_TX_DS)) 
	{
		/* Successfully sent */
		return nRF24L01P_Transmit_Status_Ok;
	} 
	else if (NRF24L01_CHECK_BIT(status, NRF24L01_MAX_RT)) 
	{
		/* Message lost */
		return nRF24L01P_Transmit_Status_Lost;
	}
	
	/* Still sending */
	return nRF24L01P_Transmit_Status_Sending;
}
//---------------------------------------------------
void nRF24L01P_SoftwareReset(void) 
{
	uint8_t data[5];
	
	nRF24L01P_WriteRegister(nRF_CONFIG, nRF_DEFAULT_VAL_CONFIG);				//00h = 08h
	nRF24L01P_WriteRegister(nRF_EN_AA,	nRF_DEFAULT_VAL_EN_AA);					//01h = 3Fh
	nRF24L01P_WriteRegister(nRF_EN_RXADDR,nRF_DEFAULT_VAL_EN_RXADDR);		//02h = 03h
	nRF24L01P_WriteRegister(nRF_SETUP_AW, nRF_DEFAULT_VAL_SETUP_AW);		//03h = 03h
	nRF24L01P_WriteRegister(nRF_SETUP_RETR,	nRF_DEFAULT_VAL_SETUP_RETR);//04h = 03h
	nRF24L01P_WriteRegister(nRF_RF_CH, 	nRF_DEFAULT_VAL_RF_CH);					//05h = 02h
	nRF24L01P_WriteRegister(nRF_RF_SETUP, nRF_DEFAULT_VAL_RF_SETUP);		//06h = 0Eh
	nRF24L01P_WriteRegister(nRF_STATUS, nRF_DEFAULT_VAL_STATUS);				//07h = 0Eh
	nRF24L01P_WriteRegister(nRF_OBSERVE_TX,	nRF_DEFAULT_VAL_OBSERVE_TX);//08h = 00h
	nRF24L01P_WriteRegister(nRF_RPD, nRF_DEFAULT_VAL_RPD);							//09h = 00h
	
	//P0
	data[0] = nRF_DEFAULT_VAL_RX_ADDR_P0_0;	//	E7h
	data[1] = nRF_DEFAULT_VAL_RX_ADDR_P0_1;	//	E7h
	data[2] = nRF_DEFAULT_VAL_RX_ADDR_P0_2;	//	E7h
	data[3] = nRF_DEFAULT_VAL_RX_ADDR_P0_3;	//	E7h
	data[4] = nRF_DEFAULT_VAL_RX_ADDR_P0_4;	//	E7h
	nRF24L01P_WriteRegisterMulti(nRF_RX_ADDR_P0, data, 5);
	
	//P1
	data[0] = nRF_DEFAULT_VAL_RX_ADDR_P1_0;	//	C2h
	data[1] = nRF_DEFAULT_VAL_RX_ADDR_P1_1;	//	C2h
	data[2] = nRF_DEFAULT_VAL_RX_ADDR_P1_2;	//	C2h
	data[3] = nRF_DEFAULT_VAL_RX_ADDR_P1_3;	//	C2h
	data[4] = nRF_DEFAULT_VAL_RX_ADDR_P1_4;	//	C2h
	nRF24L01P_WriteRegisterMulti(nRF_RX_ADDR_P1, data, 5);
	
	nRF24L01P_WriteRegister(nRF_RX_ADDR_P2, 	nRF_DEFAULT_VAL_RX_ADDR_P2);	//	C3h
	nRF24L01P_WriteRegister(nRF_RX_ADDR_P3, 	nRF_DEFAULT_VAL_RX_ADDR_P3);	//	C4h
	nRF24L01P_WriteRegister(nRF_RX_ADDR_P4, 	nRF_DEFAULT_VAL_RX_ADDR_P4);	//	C5h
	nRF24L01P_WriteRegister(nRF_RX_ADDR_P5, 	nRF_DEFAULT_VAL_RX_ADDR_P5);	//	C6h
	
	//TX
	data[0] = nRF_DEFAULT_VAL_TX_ADDR_0;	//	E7h
	data[1] = nRF_DEFAULT_VAL_TX_ADDR_1;	//	E7h
	data[2] = nRF_DEFAULT_VAL_TX_ADDR_2;	//	E7h
	data[3] = nRF_DEFAULT_VAL_TX_ADDR_3;	//	E7h
	data[4] = nRF_DEFAULT_VAL_TX_ADDR_4;	//	E7h
	nRF24L01P_WriteRegisterMulti(nRF_TX_ADDR, data, 5);
	
	nRF24L01P_WriteRegister(nRF_RX_PW_P0, 	nRF_DEFAULT_VAL_RX_PW_P0);	//	00h
	nRF24L01P_WriteRegister(nRF_RX_PW_P1, 	nRF_DEFAULT_VAL_RX_PW_P1);	//	00h
	nRF24L01P_WriteRegister(nRF_RX_PW_P2, 	nRF_DEFAULT_VAL_RX_PW_P2);	//	00h
	nRF24L01P_WriteRegister(nRF_RX_PW_P3, 	nRF_DEFAULT_VAL_RX_PW_P3);	//	00h
	nRF24L01P_WriteRegister(nRF_RX_PW_P4, 	nRF_DEFAULT_VAL_RX_PW_P4);	//	00h
	nRF24L01P_WriteRegister(nRF_RX_PW_P5, 	nRF_DEFAULT_VAL_RX_PW_P5);	//	00h
	nRF24L01P_WriteRegister(nRF_FIFO_STATUS, nRF_DEFAULT_VAL_FIFO_STATUS);//11h
	nRF24L01P_WriteRegister(nRF_DYNPD, 		nRF_DEFAULT_VAL_DYNPD);				//	00h
	nRF24L01P_WriteRegister(nRF_FEATURE, 	nRF_DEFAULT_VAL_FEATURE);			//	00h
}
//---------------------------------------------------
uint8_t nRF24L01P_GetRetransmissionsCount(void) 
{
	/* Low 4 bits */
	return nRF24L01P_ReadRegister(nRF_OBSERVE_TX) & 0x0F;
}
//---------------------------------------------------
void nRF24L01P_SetChannel(uint8_t channel) 
{
	if (channel <= 125 && channel != nRF_str.Channel) 
	{
		/* Store new channel setting */
		nRF_str.Channel = channel;
		/* Write channel */
		nRF24L01P_WriteRegister(nRF_RF_CH, channel);
	}
}
//---------------------------------------------------
void nRF24L01P_SetRF(nRF24L01P_DataRate_t DataRate, nRF24L01P_OutputPower_t OutPwr) 
{
	uint8_t tmp = 0;
	nRF_str.DataRate = DataRate;
	nRF_str.OutPwr = OutPwr;
	
	if (DataRate == nRF24L01P_DataRate_2M)
	{
		tmp |= 1 << NRF24L01_RF_DR_HIGH;
	} 
	else if (DataRate == nRF24L01P_DataRate_250k) 
	{
		tmp |= 1 << NRF24L01_RF_DR_LOW;
	}
	/* If 1Mbps, all bits set to 0 */
	
	if (OutPwr == nRF24L01P_OutputPower_0dBm) 
	{
		tmp |= 3 << NRF24L01_RF_PWR;
	} 
	else if (OutPwr == nRF24L01P_OutputPower_M6dBm) 
	{
		tmp |= 2 << NRF24L01_RF_PWR;
	} 
	else if (OutPwr == nRF24L01P_OutputPower_M12dBm) 
	{
		tmp |= 1 << NRF24L01_RF_PWR;
	}
	
	nRF24L01P_WriteRegister(nRF_RF_SETUP, tmp);
}
//---------------------------------------------------
//---------------------------------------------------

