//	_DEUS (Moscow) USB2512B - USBHUB
//	������ 2018.02.18
//	����� 16 ���

#include "stm32f0xx_hal.h"
#include "i2c.h"
//#include "tim.h"
//#include "usart.h"
#include "gpio.h"
//#include "sh2.h"
#include "USB2512B_box.h"
///#include "usbd_cdc_if.h"
#include "ctype.h"
#include "string.h"
//--------------------------------------------
// ��������� ��� ������ � ������ ��������� BNO080
I2C2_str HUB_read;
I2C2_str HUB_write;
USB2512B_str HUB_2512;
//--------- function declarations ------------
void stop_10mks(void);
void SMB_Stop(void);
void SMB_Start(void);
void SMB_SCL_ON(void);
void SMB_SCL_OFF(void);
void SMB_SDA_ON(void);
void SMB_SDA_OFF(void);
void SMB_SDA_Z(uint8_t d);
uint8_t ACK(void);
uint8_t SMB_write_byte(uint8_t byte);
uint8_t SMB_read_byte(void);
uint8_t SMB_write_USBADDR(void);
uint8_t SMB_read_USBADDR(void);
void SMB_write_packet(uint8_t *Buf, uint8_t N);
void SMB_read_packet(uint8_t N);
void Send_S_Byte_P(uint8_t addr, uint8_t data);
//--------------------------------------------

void test_Dip4(void)
{
	GPIOA->ODR ^= (1<<1);
}
//--------------------------------------------
void test_Dip5(void)
{
	GPIOA->ODR ^= (1<<4);
}
//--------------------------------------------
//	����� ����� 1 ������������. ���� �� ������������
void stop_10mks(void)
{
	uint16_t i;	
	for (i=0; i<20; i++)
		;
}
//--------------------------------------------
void InitUSB2512B(void)
{
// ��������� ��������� USB_HUB_2512B
	HUB_2512.VendorIDLSB 	= 0x24;				//00h = 0x24
	HUB_2512.VendorIDMSB 	= 0x04;				//01h = 0x04
	HUB_2512.ProductIDLSB = 0x12;				//02h = 0x12
	HUB_2512.ProductIDMSB = 0x25;				//03h = 0x25
	HUB_2512.DeviceIDLSB 	= 0xA0;				//04h = 0xA0
	HUB_2512.DeviceIDMSB 	= 0x0B;				//05h = 0x0B
	HUB_2512.ConfigDataByte1 = 0x9B;		//06h = 0x9B	
	HUB_2512.ConfigDataByte2 = 0x20;		//07h = 0x20
	HUB_2512.ConfigDataByte3 = 0x02;		//08h = 0x02
	HUB_2512.NonRemovableDevices = 0x06;//09h = 0x00
	HUB_2512.PortDisableSelf 	= 0x00;		//0Ah = 0x00
	HUB_2512.PortDisableBus 	= 0x00;		//0Bh = 0x00
	HUB_2512.MaxPowerSelf 		= 0x32;		//0Ch = 0x01 = 100mA
	HUB_2512.MaxPowerBus 			= 0xFF;		//0Dh = 0x32 = 500mA
	HUB_2512.HubMaxCurrentSelf = 0x32;	//0Eh = 0x01 = 100mA
	HUB_2512.HubMaxCurrentBus = 0xFF;		//0Fh = 0x32 = 500mA
	HUB_2512.PowerOnTime 			= 0x32;		//10h = 0x32
	
	uint8_t *ptr;
	uint8_t D[256];
	uint8_t N = sizeof(HUB_2512);
	memset(D,0,256);
	ptr = &HUB_2512.VendorIDLSB;
	uint16_t i;
	for (i=0; i<N; i++)
		D[i] = *(ptr+i);
	
	D[255] = 0x01;	//	���������� USB_HUB
	
	for (i=0; i<256; i++)
	{	
		Send_S_Byte_P(i,D[i]);
		stop_10mks();
	}
}

//--------------------------------------------
void SMB_Stop(void)
{
	SDA_OFF;	//	PB.11:= 0 (SDA)
	stop_10mks();
	SCL_ON;		//	PB.10:= 1 (SCL)
	stop_10mks();
	SDA_ON;		//	PB.11:= 1	(SDA)
}
//--------------------------------------------
void SMB_Start(void)
{
	SDA_OFF;	//	PB.11:= 0	(SDA)	
	stop_10mks();
	SCL_OFF;	//	PB.10:= 0 (SCL)
	stop_10mks();
}
//--------------------------------------------
void SMB_SCL_ON(void)
{
	SCL_ON;	//	PB.10:= 1 (SCL)
	stop_10mks();
}
//--------------------------------------------
void SMB_SDA_ON(void)
{
	SDA_ON;	//	PB.11:= 1 (SDA)
	stop_10mks();
}
//--------------------------------------------
void SMB_SCL_OFF(void)
{
	SCL_OFF;	//	PB.10:= 0 (SCL)
	stop_10mks();
}
//--------------------------------------------
void SMB_SDA_OFF(void)
{
	SDA_OFF;	//	PB.11:= 0 (SDA)
	stop_10mks();
}
//--------------------------------------------
void SMB_SDA_Z(uint8_t d)
{
	if (d == 0)
		GPIOB->MODER 	&= ~(3<<22);//	:= 00
	else
		GPIOB->MODER 	|= (1<<22);	//	:= 01	
	stop_10mks();
}
//--------------------------------------------
//	����� ����� � USB2512B
void SMB_write_packet(uint8_t *Buf, uint8_t N)
{
	uint8_t i;
	if (N == 0)
		return;
	SMB_Start();	
	if (SMB_write_USBADDR() != OK)
	{
		SMB_Stop();
		return;
	}		
	for (i=0; i<N; i++)
	{
		if (SMB_write_byte(*(Buf+i)) != OK)
		{
			SMB_Stop();
			return;
		}
	}
	SMB_Stop();
	SMB_Start();
	SMB_Stop();	
}

//--------------------------------------------
//	������ ����� �� USB2512B
void SMB_read_packet(uint8_t N)
{
	uint8_t i;
	if (N == 0)
		return;
	SMB_Start();	
	if (SMB_write_USBADDR() != OK)
	{
		SMB_Stop();
		return;
	}	
//	� ����� ������ ����� ������
	SMB_write_byte(0);
	GPIOB->ODR |= (1<<10) | (1<<11);
	stop_10mks();
	SMB_Start();
	
	if (SMB_read_USBADDR() != OK)
	{
		SMB_Stop();
		return;
	}
	//SMB_read_byte();
	for (i=0; i<0x20; i++)	
		SMB_read_byte();		
	
	SMB_Stop();
}
//--------------------------------------------
//	������ ������ ��� �����/���� �������
uint8_t SMB_write_USBADDR(void)
{
	uint8_t i,addr;	
	addr = USB2512B_ADDR & 0xFE;
	
	for (i=0;i<8;i++)
	{		
		if (addr & 0x80)
			SMB_SDA_ON();
		else
			SMB_SDA_OFF();
		SMB_SCL_ON();	
		SMB_SCL_OFF();
		addr <<= 1;		
	}
	if (ACK() != 0)
		return NOK;
	
	
	return OK;
}
//--------------------------------------------
//	������ ������ ��� �����/���� �������
uint8_t SMB_read_USBADDR(void)
{
	uint8_t i,addr;	
	addr = USB2512B_ADDR & 0xFE;
	addr |= 0x01;	//	read
	
	for (i=0;i<8;i++)
	{		
		if (addr & 0x80)
			SMB_SDA_ON();
		else
			SMB_SDA_OFF();
		SMB_SCL_ON();	
		SMB_SCL_OFF();
		addr <<= 1;		
	}
	if (ACK() != 0)
		return NOK;
	
	
	return OK;
}
//--------------------------------------------
//	������ ����� ��� �����/���� �������
uint8_t SMB_read_byte(void)
{
	uint8_t i,byte;	
	byte = 0;
	
	SMB_SDA_Z(0);	//	input mode
	for (i=0;i<8;i++)
	{		
		SMB_SCL_ON();	
		if (GPIOB->IDR & (1<<11))
			byte |= 0x01;				
		SMB_SCL_OFF();
		byte <<= 1;		
	}
	SMB_SDA_Z(1);	//	normal mode
	SMB_SDA_OFF();
	SMB_SCL_ON();
	SMB_SCL_OFF();
	//ACK();	
	
	return byte;	
}
//--------------------------------------------
//	������ ����� ��� �����/���� �������
uint8_t SMB_write_byte(uint8_t byte)
{
	uint8_t i,data;	
	data = byte;
	
	for (i=0;i<8;i++)
	{		
		if (data & 0x80)
			SMB_SDA_ON();
		else
			SMB_SDA_OFF();
		SMB_SCL_ON();	
		SMB_SCL_OFF();
		data <<= 1;		
	}
	SMB_SDA_ON();
	if (ACK() != 0)	
		return NOK;	

	return OK;	
}
//--------------------------------------------
//	���������� ������ ���� ����
void Send_S_Byte_P(uint8_t addr, uint8_t data)
{	
	SMB_Start();
	SMB_write_USBADDR();
	SMB_write_byte(addr);
	SMB_write_byte(1);
	SMB_write_byte(data);
	SMB_Stop();
}
//--------------------------------------------
//	�������� �������� ���
uint8_t ACK(void)
{
	uint8_t ret = 0;
//	���� PB.11 (SDA) - input mode			
	SMB_SDA_Z(0);
	SMB_SCL_ON();
	ret = GPIOB->IDR & (1<<11);//	PB.11 SDA
	SMB_SCL_ON();
	SMB_SCL_OFF();
	//SMB_SDA_OFF();
	SMB_SDA_Z(1);
	if (ret)
		return NOK;
	else
		return OK;
}
//--------------------------------------------
void SMBus_mode(uint8_t flag)
{	
	GPIOB->ODR |= (1<<10) | (1<<11);
	if (flag == 0)
	{
	//	������ ����� PB.10, PB.11 � I2C2	
		GPIOB->MODER 	&= ~((3<<22)|(3<<20));	//	:= 00
		GPIOB->MODER 	|=  ((2<<22)|(2<<20));	//	:= 10 - alternate mode
		stop_10mks();
		return;
	}	
//	���� ��������� �������
	GPIOB->MODER 	&= ~((3<<22)|(3<<20));	//	:= 00
	GPIOB->MODER 	|=  ((1<<22)|(1<<20));	//	:= 01 - ouput mode
	stop_10mks();
}

//--------------------------------------------
//	Reset for USB2512B ��������� USB2512B � ��������
//	CFG_SEL0 := 1 (24pin, PB.10=1)
//	CFG_SEL1 := 0 (25pin, PB.2=0)	
void ResetUSB2512B(char d1, char d0)
{
	int mem = GPIOB->MODER;
	GPIOB->ODR   &= ~(1<<14);		//	reset USB_HUB	:= 1	
	GPIOB->MODER 	&= ~((3<<20)|(3<<4));	//	:= 00
	GPIOB->MODER 	|=  ((1<<20)|(1<<4));	//	:= 01 - ouput mode		
	stop_10mks();

	if (d1)
		GPIOB->ODR 	|= (1<<2);		//	PB.2:= 1	CFG_SEL1:=1
	else
		GPIOB->ODR 	&= ~(1<<2);		//	PB.2:= 0	CFG_SEL1:=0
	
	if (d0)
		GPIOB->ODR 	|= (1<<10);		//	PB.10:= 1 CFG_SEL0:=1	
	else
		GPIOB->ODR 	&= ~(1<<10);	//	PB.10:= 0 CFG_SEL0:=0	

	stop_10mks();
	GPIOB->ODR   &= ~(1<<14);		//	reset USB_HUB	:= 0
	stop_10mks();
	GPIOB->ODR   |= (1<<14);		//	reset USB_HUB	:= 1
	GPIOB->MODER = mem;
}

//--------------------------------------------
//	HAL_Delay(100);

//-------------------------------------------------

