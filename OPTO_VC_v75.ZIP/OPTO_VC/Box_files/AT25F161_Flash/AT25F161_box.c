//---------------------------------------------------
#include "AT25F161_box.h"
#include "BNO080_box.h"
//---------------------------------------------------

//-------------- function prototypes ----------------
void delay(void);
void CSHigh(void);
void CSLow(void);
void CLK_on(void);
void CLK_off(void);
//void BoxInitSPI1(void);
void SEND_N_Bytes(uint8_t *ptr, uint8_t N);
uint8_t SEND_SPI_Byte(uint8_t spi_out);
void Read_Bytes_From_AT25F161(un char *Buf, un char N);
void Write_Bytes_To_AT25F161(un char *Buf, un char N);

//---------------------------------------------------
void delay(void)
{
	//uint16_t i;	
	//for (i=0; i<3; i++) ;
}
//---------------------------------------------------
void CSHigh(void)
{
	GPIOB->ODR |= 1<<6; //PB.6 := 1
}
//---------------------------------------------------
void CSLow(void)
{
	GPIOB->ODR &= ~(1<<6); //PB.6 := 0
}

//---------------------------------------------------
void CLK_on(void)
{
	GPIOB->ODR |= (1<<3); //PB.3 := 1
}
//---------------------------------------------------
void CLK_off(void)
{
	GPIOB->ODR &= ~(1<<3); //PB.3 := 0
}
//---------------------------------------------------
//void BoxInitSPI1(void)
//{
//	SPI1->CR1 |= 1<<6;
//}

//---------------------------------------------------
void SEND_N_Bytes(uint8_t *ptr, uint8_t N)
{
	uint8_t i;
	GPIOB->ODR &= ~(1<<6);		//	CS := 0	
	delay();
	for (i=0; i<N; i++)
	{
		SEND_SPI_Byte(*(ptr+i));
		delay();
	}
	GPIOB->ODR |= (1<<6);			//	CS := 1
}
//---------------------------------------------------
//	�������� (� ��������) ���� �� AT25F161
uint8_t SEND_SPI_Byte(uint8_t spi_out)
{		
	un char i, spi_in, M;
	for (i=0, M=0x80, spi_in=0; i<8; i++)
	{			
		delay();
		if (spi_out & M)
			GPIOB->ODR |= (1<<5);		//	MOSI:=1
		else
			GPIOB->ODR &= ~(1<<5);	//	MOSI:=0
		delay();
		M >>= 1;									//	shift maska M
		spi_in <<= 1;
		GPIOB->ODR |= (1<<3); 		//	CLK := 1
		
		if ((GPIOB->IDR & (1<<4)) != 0)
			spi_in |= 0x01;
		
		delay();		
		GPIOB->ODR &= ~(1<<3); 		// CLK := 0		
	}
	return spi_in;
}

//-------------------------------------------------
void Write_Bytes_To_AT25F161(un char *Buf, un char N)
{
	un char i;
	un char *b = Buf;
	GPIOB->ODR &= ~(1<<6);		//	CS := 0	
	for (i=0; i<N; i++)
		SEND_SPI_Byte(*(b+i));
	GPIOB->ODR |= (1<<6);			//	CS := 1
}
//-------------------------------------------------
void Read_Bytes_From_AT25F161(un char *Buf, un char N)
{
	un char i;
	GPIOB->ODR &= ~(1<<6);		//	CS := 0	
	for (i=0; i<N; i++)
		Buf[i] = SEND_SPI_Byte(0xFF);
	GPIOB->ODR |= (1<<6);			//	CS := 1
}
//-------------------------------------------------
uint8_t Read_AT25F161_Status(void)
{
	uint8_t D;
	CSLow();
	D = SEND_SPI_Byte(0xFF);
	CSHigh();
	return D;
}

//---------------------------------------------------
//---------------------------------------------------

