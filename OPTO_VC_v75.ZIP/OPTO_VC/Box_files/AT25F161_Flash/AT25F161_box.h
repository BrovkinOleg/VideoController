
#ifndef AT25F161_box_H
#define AT25F161_box_H 

/*
SCK			PB3		SCK pin for SPI
MISO		PB4		MISO pin for SPI
MOSI		PB5		MOSI pin for SPI
CSN			PA8		CS for AT25F161
*/
	
//--------------------------------------------------------	
#include "stm32f0xx_hal.h"
#include "gpio.h"

//--------------------------------------------------------
#define un unsigned

//--------------------------------------------------------


#endif	// AT25F161_box_H 

