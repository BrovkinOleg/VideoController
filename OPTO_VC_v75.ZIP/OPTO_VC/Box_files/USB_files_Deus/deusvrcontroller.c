#include "deusvrcontroller.h"

//���� ����������
DVRC_TypeDef dvrc = {1400, 100, 0, 0};

//USB ���������
USBConnection DeusTrackUSB = {USB, HID, 0x4572, 0x0003, "Deus", "Wireless VR Controller",
								"000000000000", DVRC_USB_callback };
SensorDataReport SensorData = { 1 };

//������������ ������
//					 SDA   SCL	 CS	   INT	 NRST 400kHz  10ms Address
BNO080 IMU = { I2C2, PB14, PB13, PC14, PC13, PB9, 400000, 10,  0x68, DVRC_IMU_callback };

//���������������
//							 MOSI MISO SCK  CS   CE   IRQ	6MHz	 50ms 55ch
NRF24L01P RadioTRX = { SPI1, PB5, PB4, PB3, PB6, PB7, PA10, 6000000, 50,  55,  NRF24_PACKET_SIZE,
					   0, NRF24L01P_2Mbps, NRF24L01P_0dBm, DVRC_Radio_callback, "0000", "0001"};

//������
Button BT_Wakeup = { PA7, ExtInt, 1, 0, DVRC_BT_WakeUp_callback };
Button BT_Left = { PA0, ExtInt, 1, 0, DVRC_BT_Left_callback };
Button BT_Right = { PA4, ExtInt, 1, 0, DVRC_BT_Right_callback };
Button BT_Up = { PA1, ExtInt, 1, 0, DVRC_BT_Up_callback };
Button BT_Down = { PC15, ExtInt, 1, 0, DVRC_BT_Down_callback };
Button BT_Ok = { PA2, ExtInt, 1, 0, DVRC_BT_Ok_callback };
Button BT_Top1 = { PB8, ExtInt, 1, 0, DVRC_BT_Top1_callback };
Button BT_VolumeUp = { PA5, ExtInt, 1, 0, DVRC_BT_VolumeUp_callback };
Button BT_VolumeDown = { PA6, ExtInt, 1, 0, DVRC_BT_VolumeDown_callback };

//���������
Led	RedLED = {PA3, 1, 0, Led_Simple, TIM2, CH4, 0.0002 };

//��������� ������� ������������

int main(void)
{
	DVRC_Init(&dvrc);
	
	while (1)
	{
		//������ ������������ BNO080
		//halTask(NULL);
		
		//���������� �������� ������
		SensorData.buttons.wake_up = !HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_7);
		SensorData.buttons.left = !HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0);
		SensorData.buttons.right = !HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_4);
		SensorData.buttons.up = !HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_1);
		SensorData.buttons.down = !HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_15);
		SensorData.buttons.ok = !HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_2);
		SensorData.buttons.top1 = !HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_8);
		SensorData.buttons.volup = !HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_5);
		SensorData.buttons.voldn = !HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_6);
		
		//����������� ���������� ������ � ����� �������� USB
		USB_SendDeviceData((u8*)&SensorData, SENSOR_DATA_REPORT);
		
		//�������� ��� USB
		HAL_Delay(1);
	}
}

// (u8[]){0x04,0x06,0x02,0x45,0xF1,0x01,0x00,0x08};

void DVRC_Init(DVRC_TypeDef* dvrc)
{
	HAL_StatusTypeDef init_status;
	init_status = MCU_Init();
	init_status |= LED_Init(&RedLED);

	Button BT_Wakeup = { PA7, ExtInt, 1, 0, DVRC_BT_WakeUp_callback };
	Button BT_Left = { PA0, ExtInt, 1, 0, DVRC_BT_Left_callback };
	Button BT_Right = { PA4, ExtInt, 1, 0, DVRC_BT_Right_callback };
	Button BT_Up = { PA1, ExtInt, 1, 0, DVRC_BT_Up_callback };
	Button BT_Down = { PC15, ExtInt, 1, 0, DVRC_BT_Down_callback };
	Button BT_Ok = { PA2, ExtInt, 1, 0, DVRC_BT_Ok_callback };
	Button BT_Top1 = { PB8, ExtInt, 1, 0, DVRC_BT_Top1_callback };
	Button BT_VolumeUp = { PA5, ExtInt, 1, 0, DVRC_BT_VolumeUp_callback };
	Button BT_VolumeDown = { PA6, ExtInt, 1, 0, DVRC_BT_VolumeDown_callback };

	//��������� ������� ��� ������ �� ����
	GPIO_InitTypeDef io;
	io.Mode = GPIO_MODE_INPUT;
	io.Speed = GPIO_SPEED_FREQ_LOW;
	io.Pull = GPIO_NOPULL;
	io.Pin = GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_4 | GPIO_PIN_5 | GPIO_PIN_6 | GPIO_PIN_7;
	HAL_GPIO_Init(GPIOA, &io);
	io.Pin = GPIO_PIN_8;
	HAL_GPIO_Init(GPIOB, &io);
	io.Pin = GPIO_PIN_15;
	HAL_GPIO_Init(GPIOC, &io);


	//init_status |= Button_Init(&BT_Wakeup);
	//init_status |= Button_Init(&BT_Left);
	//init_status |= Button_Init(&BT_Right);
	//init_status |= Button_Init(&BT_Up);
	//init_status |= Button_Init(&BT_Down);
	//init_status |= Button_Init(&BT_Ok);
	//init_status |= Button_Init(&BT_Top1);
	//init_status |= Button_Init(&BT_VolumeUp);
	//init_status |= Button_Init(&BT_VolumeDown);
	//Button_TimerInit(TIM7);
// 	init_status |= BNO080_Init(&IMU);
	//init_status |= NRF24L01P_Init(&RadioTRX);
	init_status |= USBConnection_Init(&DeusTrackUSB);

	if (init_status != HAL_OK)
	{
		DVRC_InitError();
	}
}

void DVRC_GetTrackingData()
{

}

void DVRC_SendTrackingData(DVRC_Interface dst)
{

}

void DVRC_SendDeviceInfo(DVRC_Interface dst)
{

}

void DVRC_WaitForReceiveData(DVRC_Interface src)
{

}

void DVRC_WaitForReceiveCommand(DVRC_Interface src)
{

}

void DVRC_Sleep()
{

}

void DVRC_Wakeup()
{

}

void DVRC_UpdateFirmware(DVRC_Interface src)
{

}

void DVRC_LowBatteryAlarm()
{

}

void DVRC_BT_WakeUp_callback(ButtonState new_state)
{
	if (new_state == Button_Pressed)
	{
		LED_On(&RedLED);
	}
	if (new_state == Button_Released)
	{
	}
}


void DVRC_BT_Left_callback(ButtonState new_state)
{
	if (new_state == Button_Pressed)
	{
		LED_Off(&RedLED);
	} 
	if (new_state == Button_Released)
	{
	}
}

void DVRC_BT_Right_callback(ButtonState new_state)
{
	if (new_state == Button_Pressed)
	{
		LED_On(&RedLED);
	}
	if (new_state == Button_Released)
	{
	}
}

void DVRC_BT_Up_callback(ButtonState new_state)
{
	if (new_state == Button_Pressed)
	{
		LED_Off(&RedLED);
	}
	if (new_state == Button_Released)
	{
	}
}

void DVRC_BT_Down_callback(ButtonState new_state)
{
	if (new_state == Button_Pressed)
	{
		LED_On(&RedLED);
	}
	if (new_state == Button_Released)
	{
	}
}

void DVRC_BT_Ok_callback(ButtonState new_state)
{
	if (new_state == Button_Pressed)
	{
		LED_Off(&RedLED);
	}
	if (new_state == Button_Released)
	{
	}
}

void DVRC_BT_Top1_callback(ButtonState new_state)
{
	if (new_state == Button_Pressed)
	{
		LED_On(&RedLED);
	}
	if (new_state == Button_Released)
	{
	}
}
void DVRC_BT_VolumeUp_callback(ButtonState new_state)
{
	if (new_state == Button_Pressed)
	{
		LED_Off(&RedLED);
	}
	if (new_state == Button_Released)
	{
	}
}

void DVRC_BT_VolumeDown_callback(ButtonState new_state)
{
	if (new_state == Button_Pressed)
	{
		LED_On(&RedLED);
	}
	if (new_state == Button_Released)
	{
	}
}

void DVRC_IMU_callback(uint8_t* data)
{

}

void DVRC_USB_callback(uint8_t request_id, uint8_t* data)
{

}

void DVRC_Radio_callback(uint8_t request_id, uint8_t* data)
{

}

void DVRC_InitError()
{
	LED_On(&RedLED);
	while (1);
}

void DVRC_Error()
{
	while (1);
}
