#include "deus_usb.h"
#include "usb_device.h"
#include "usbd_customhid_if.h"
#include "FWUpdate.h"
#include "gpio.h"

u8 packet_id = 1;
USB_TrackingReport TrackingReport;
DeviceStatus device_status = Device_NotFound;

void DeusReportTester(void);
void DEUS_Configure(USB_FeatureRequestType FeatureType, USB_ConfigReport* report);
void DEUS_Status(USB_FeatureRequestType FeatureType, USB_StatusReport* report);
void DEUS_Calibrate(USB_FeatureRequestType FeatureType, USB_CalibrationReport* report);
void DEUS_DFUPrepare(USB_DFUPrepareReport* report);
void DEUS_PowerControl(USB_FeatureRequestType FeatureType, USB_PowerControlReport* report);

void DEUS_SendTestTrackingData()
{
	USB_SendDeviceData((uint8_t*)&TrackingReport, HAPTIC_CONTROL_REPORT);
}

void DEUS_USB_InTransferCallback()
{
	(packet_id < 3) ? (packet_id++) : (packet_id = 1);
}

int8_t DEUS_ParseHostData(USB_FeatureRequestType FeatureType, USB_ReportType ReportType, USB_ReportID ReportID, uint8_t* pData, uint16_t* length)
{
	int8_t status = 0;
	switch (ReportType)
	{
	case FeatureReport:
		{
			switch(ReportID)
			{
			case CONFIG_REPORT:
				{
					DEUS_Configure(FeatureType, (USB_ConfigReport*)pData);
					USB_SetReportID(pData, CONFIG_REPORT);
					*length = sizeof(USB_ConfigReport);
					break;
				}
			case STATUS_REPORT:
				{
					DEUS_Status(FeatureType, (USB_StatusReport*)pData);
					USB_SetReportID(pData, STATUS_REPORT);
					*length = sizeof(USB_StatusReport);
					break;
				}
			case POWER_CONTROL_REPORT:
				{
					DEUS_PowerControl(FeatureType, (USB_PowerControlReport*)pData);
					break;
				}
			case DFU_PREPARE_REPORT:
				{
					DEUS_DFUPrepare((USB_DFUPrepareReport*)pData);
					break;
				}
			case LICENSE_REPORT:
				{
					DeusReportTester();
					break;
				}
			case CALIBRATION_REPORT:
				{
					DEUS_Calibrate(FeatureType, (USB_CalibrationReport*)pData);
					USB_SetReportID(pData, CALIBRATION_REPORT);
					*length = sizeof(USB_CalibrationReport);
					break;
				}
			default: break;
			}
			break;
		}
	case OutReport:
		{
			switch(ReportID)
			{
			case DFU_DOWNLOAD_REPORT:
				{
					//FW_DownloadPart(&hBoot, ((USB_DFUDownloadReport*)pData)->FWPart.Data);
					break;
				}
			case HAPTIC_CONTROL_REPORT:
				{
					DeusReportTester();
					break;
				}
			default: break;
			}
			break;
		}
	default: break;
	}
	return status;
}

void DEUS_Configure(USB_FeatureRequestType FeatureType, USB_ConfigReport* report)
{
}

void DEUS_Status(USB_FeatureRequestType FeatureType, USB_StatusReport* report)
{
	if (FeatureType == USB_FeatureGet)
	{
		memset(report, 0, sizeof(USB_StatusReport));
		report->ProtocolVersion = DeusProtocolVersion;
		report->State = device_status;
	}
	else if (FeatureType == USB_FeatureSet)
	{
		DeusReportTester();
	}
}

void DEUS_Calibrate(USB_FeatureRequestType FeatureType, USB_CalibrationReport* report)
{
	if (FeatureType == USB_FeatureGet)
	{
		//DEUS_LoadCalibrationData(&report->Calibration);
	}
	else if (FeatureType == USB_FeatureSet)
	{
		//DEUS_SaveCalibrationData(&report->Calibration);
	}
}

void DEUS_PowerControl(USB_FeatureRequestType FeatureType, USB_PowerControlReport* report)
{
	if (FeatureType == USB_FeatureGet)
	{
		//..
		DeusReportTester();
	}
	else if (FeatureType == USB_FeatureSet)
	{
		switch(report->TargetDevice)
		{
		case HMD:
			{
				if (report->PowerState.STM32 == Normal)
				{
					DeusReportTester();
				}
				else if (report->PowerState.STM32 == Standby)
				{
					DeusReportTester();
				}
				else if (report->PowerState.STM32 == Reload)
				{
					FW_DeviceReload();
				}
				else if (report->PowerState.STM32 == DFU)
				{
					//FW_SetUpdateNeedFlag(&hBoot, FW_Info_RTC_Backup);
					FW_DeviceReload();
				}
				if (report->PowerState.FPGA == Normal)
				{
					DeusReportTester();
				}
				else if (report->PowerState.FPGA == Standby)
				{
					DeusReportTester();
				}
				else if (report->PowerState.FPGA == Reload)
				{
					DeusReportTester();
				}
				else if (report->PowerState.FPGA == DFU)
				{
					DeusReportTester();
				}
				if (report->PowerState.NRF52 == Normal)
				{
					DeusReportTester();
				}
				else if (report->PowerState.NRF52 == Standby)
				{
					DeusReportTester();
				}
				else if (report->PowerState.NRF52 == Reload)
				{
					DeusReportTester();
				}
				else if (report->PowerState.NRF52 == DFU)
				{
					DeusReportTester();
				}
			}
		case CTR_LEFT:
			{
				DeusReportTester();
			}
		case CTRL_RIGHT:
			{
				DeusReportTester();
			}
		case LHOUSE1:
			{
				DeusReportTester();
			}
		case LHOUSE2:
			{
				DeusReportTester();
			}
		}
	}
}

void DEUS_DFUPrepare(USB_DFUPrepareReport* report)
{
	//Save info to low power region and reload device
	//FW_FirmwareUpdateRequested(&hBoot, (FW_Info*)&(report->NewFirmware));
}

//void DEUS_PowerStateChange()

void DeusReportTester()
{
	//HAL_GPIO_TogglePin(GPIOA, LED_RED);
}
