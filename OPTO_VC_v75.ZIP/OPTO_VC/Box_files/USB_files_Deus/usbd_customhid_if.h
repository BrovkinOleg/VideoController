#ifndef __USBD_CUSTOM_HID_IF_H_
#define __USBD_CUSTOM_HID_IF_H_

#ifdef __cplusplus
 extern "C" {
#endif

#include "usbd_customhid.h"

/** @defgroup USBD_CUSTOM_HID_Exported_Variables
  * @{
  */ 
extern USBD_CUSTOM_HID_ItfTypeDef  USBD_CustomHID_fops_FS;
int8_t USBD_CUSTOM_HID_Send_FS(uint8_t *report, uint16_t len);

#ifdef __cplusplus
}
#endif

#endif /* __USBD_CUSTOM_HID_IF_H_ */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
