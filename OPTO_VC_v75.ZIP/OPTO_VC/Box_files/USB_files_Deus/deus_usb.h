#ifndef __DEUS_USB_H
#define __DEUS_USB_H

#include "deus_types.h"

static const Version DeusProtocolVersion = 
{
	.major = 0,
	.minor = 2,
	.revision = 4
};

///////////////////////USB report IDs////////////////////////
typedef enum
{
	SENSOR_DATA_REPORT = 1,	//[1]IN
	CONFIG_REPORT,			//[2]FEATURE
	STATUS_REPORT,			//[3]FEATURE
	DEBUG_REPORT,			//[4]FEATURE
	POWER_CONTROL_REPORT,	//[5]FEATURE
	DFU_PREPARE_REPORT,		//[6]FEATURE
	DFU_DOWNLOAD_REPORT,	//[7]OUT
	CALIBRATION_REPORT,		//[8]FEATURE
	HAPTIC_CONTROL_REPORT,	//[9]OUT
	LICENSE_REPORT			//[10]FEATURE
} USB_ReportID;

/////////////////////////////////////////////////////////////////////////////////////
///////////////////////////���� ������ ��� �������� �� USB///////////////////////////
/////////////////////////////////////////////////////////////////////////////////////

#pragma pack(push,1)

typedef struct
{
	uint8_t 		ReportID;				//1b
	uint8_t     LastCommandID;	//1b
	IMU_Data		IMU;						//18b
	RawPositionData	POS;				//42b
} USB_TrackingReport; //63
/*
typedef struct
{
	USB_ReportID	ReportID;
	Device			SourceDevice;
	DeviceStatus	Status;
	IMU_Data		RawOrient;
	int16_t		    Temperature;
	POS_USB_Data	RawPosition;
	uint16_t		ButtonStates;
	uint8_t 		TrigPower;
	TOUCH_Data		Touch;
	uint8_t			BatteryStatus;
	uint16_t 		IPDData;
} USB_TrackingReport; //63
*/
typedef struct
{
	USB_ReportID 	ReportID;
	ConfigCMD		ConfigCMD;
	uint8_t 		data[USB_MAX_DATA_SIZE];
} USB_ConfigReport;

typedef struct
{
	USB_ReportID	ReportID;
	Version			ProtocolVersion;
	Device			TargetDevice;
	DeviceStatus	State;
} USB_StatusReport;	//40

typedef struct
{
	USB_ReportID	ReportID;
	IMU_Data		RawOrient;
	uint16_t		Temperature;
	RawPositionData	RawPosition;
} USB_DebugReport;	//11

typedef struct
{
	USB_ReportID 	ReportID;
	Device 			TargetDevice;
	DevicePower		PowerState;
} USB_PowerControlReport; //4

typedef struct
{
	USB_ReportID	ReportID;
	Device			TargetDevice;
	DeviceIC		TargetIC;
	FirmwareInfo	NewFirmware;
	TargetInfo		Info;
} USB_DFUPrepareReport; //11

typedef struct
{
	USB_ReportID 	ReportID;
	FW_Part_Data	FWPart;
} USB_DFUDownloadReport; //64

typedef struct
{
	USB_ReportID 	ReportID;		//1b
	TrackerCalibrationData Calibration;
} USB_CalibrationReport; //64b

typedef struct
{
	USB_ReportID	ReportID;
	Device 			TargetDevice;
	Haptic_Data		Haptic;
} USB_HapticActionReport; //4

typedef struct
{
	USB_ReportID 	ReportID;	//1b
	LockState		LicLocked;	//1b
	uint8_t			LicenseKey[32];
} USB_LicenseReport;	//34b

void DeusReportTester(void);
void DEUS_Configure(USB_FeatureRequestType FeatureType, USB_ConfigReport* report);
void DEUS_Status(USB_FeatureRequestType FeatureType, USB_StatusReport* report);
void DEUS_Calibrate(USB_FeatureRequestType FeatureType, USB_CalibrationReport* report);
void DEUS_DFUPrepare(USB_DFUPrepareReport* report);
void DEUS_PowerControl(USB_FeatureRequestType FeatureType, USB_PowerControlReport* report);
void DEUS_SendTestTrackingData(void);
void DEUS_USB_InTransferCallback(void);
void USB_SendDeviceData(uint8_t* data, USB_ReportID report);
//void DEUS_SendFWUpdateReadyPacket();
int8_t DEUS_ParseHostData(USB_FeatureRequestType FeatureType, USB_ReportType ReportType, USB_ReportID ReportID, uint8_t* pData, uint16_t* length);

#pragma pack(pop)
#endif
