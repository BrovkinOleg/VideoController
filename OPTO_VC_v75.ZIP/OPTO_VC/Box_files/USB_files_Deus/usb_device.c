#include "usb_device.h"
#include "usbd_core.h"
#include "usbd_desc.h"
#include "usbd_customhid.h"
#include "usbd_customhid_if.h"
#include "deus_usb.h"

USBD_HandleTypeDef hUsbDeviceFS;

HAL_StatusTypeDef USB_DeviceInit()
{
	USBD_StatusTypeDef status = USBD_OK;
	status |= USBD_Init(&hUsbDeviceFS, &FS_Desc, DEVICE_FS);
	status |= USBD_RegisterClass(&hUsbDeviceFS, &USBD_CUSTOM_HID);
	status |= USBD_CUSTOM_HID_RegisterInterface(&hUsbDeviceFS, &USBD_CustomHID_fops_FS);
	status |= USBD_Start(&hUsbDeviceFS);
	return (HAL_StatusTypeDef)status;
}

void USB_DeviceDeInit()
{
	USBD_Stop(&hUsbDeviceFS);
	USBD_DeInit(&hUsbDeviceFS);
}

void USB_SetReportID(uint8_t* buffer, uint8_t ID)
{
	buffer[0] = ID;
}

void USB_SendDeviceData(uint8_t* data, USB_ReportID report_id)
{
	USB_SetReportID(data, report_id);
	USBD_CUSTOM_HID_Send_FS(data, 64);
}

int8_t USB_OutTransferCallback(USB_FeatureRequestType FeatureType, USB_ReportType ReportType, USB_ReportID ReportID, uint8_t* pData, uint16_t* length)
{
	return DEUS_ParseHostData(FeatureType, ReportType, ReportID, pData, length);
}

int8_t USB_InTransferCallback()
{
	DEUS_USB_InTransferCallback();
	return 0;
}
