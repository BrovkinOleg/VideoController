#include "usb_connection.h"

HAL_StatusTypeDef USBConnection_Init(USBConnection* usb_connection)
{
	return USB_DeviceInit();
}
