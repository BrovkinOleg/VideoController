#pragma once
#include "mcu.h"
#include "nrf24l01p.h"
#include "button.h"
#include "bno080.h"
#include "led.h"
#include "battery_charger.h"
#include "battery_monitor.h"
#include "usb_connection.h"
#include "deus_types.h"

typedef enum
{
	Radio,
	USB_PC
} DVRC_Interface;

typedef struct
{
	u16 BatteryCapacity; //mAh
	u8	BatteryCurrentCharge; //percent
	u8	ChargingStatus;
	u8	DefaultRadioChannel;
} DVRC_TypeDef;

void DVRC_Init(DVRC_TypeDef* dvrc);
void DVRC_GetTrackingData(void);
void DVRC_SendTrackingData(DVRC_Interface dst);
void DVRC_SendDeviceInfo(DVRC_Interface dst);
void DVRC_WaitForReceiveData(DVRC_Interface src);
void DVRC_WaitForReceiveCommand(DVRC_Interface src);
void DVRC_Sleep(void);
void DVRC_Wakeup(void);
void DVRC_UpdateFirmware(DVRC_Interface src);
void DVRC_LowBatteryAlarm(void);

void DVRC_BT_WakeUp_callback(ButtonState new_state);
void DVRC_BT_Left_callback(ButtonState new_state);
void DVRC_BT_Right_callback(ButtonState new_state);
void DVRC_BT_Up_callback(ButtonState new_state);
void DVRC_BT_Down_callback(ButtonState new_state);
void DVRC_BT_Ok_callback(ButtonState new_state);
void DVRC_BT_Top1_callback(ButtonState new_state);
void DVRC_BT_VolumeUp_callback(ButtonState new_state);
void DVRC_BT_VolumeDown_callback(ButtonState new_state);
void DVRC_IMU_callback(uint8_t* data);
void DVRC_USB_callback(uint8_t request_id, uint8_t* data);
void DVRC_Radio_callback(uint8_t request_id, uint8_t* data);

void DVRC_InitError(void);
void DVRC_RuntimeError(void);
