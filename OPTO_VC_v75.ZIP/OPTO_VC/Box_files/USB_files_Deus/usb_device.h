#ifndef __usb_device_H
#define __usb_device_H
#ifdef __cplusplus
 extern "C" {
#endif

#include "stm32f0xx.h"
#include "usbd_def.h"
#include "deus_usb.h"

#define USB_VID						0x4766
#define USB_PID						0x0001

#define USB_PACKET_SIZE				64
#define USB_ENDPOINT_SIZE			64

#define USB_ENDPOINT_IN_ADDRESS		0x81
#define USB_ENDPOINT_IN_SIZE		USB_ENDPOINT_SIZE
#define USB_PACKET_IN_SIZE			USB_PACKET_SIZE

#define USB_ENDPOINT_OUT_ADDRESS	0x01
#define USB_ENDPOINT_OUT_SIZE		USB_ENDPOINT_SIZE
#define USB_PACKET_OUT_SIZE			USB_PACKET_SIZE

#define DEVICE_VERSION_MAJOR		1
#define DEVICE_VERSION_MINOR		1

typedef enum
{
	SourceDevice_HMD = 0,
	SourceDevice_LCTRL,
	SourceDevice_RCTRL
} SourceDevice_t;

extern USBD_HandleTypeDef hUsbDeviceFS;
HAL_StatusTypeDef USB_DeviceInit(void);
void USB_DeviceDeInit(void);
void USB_SetReportID(uint8_t* buffer, uint8_t ID);
void USB_SendDeviceData(uint8_t* data, USB_ReportID report_id);
int8_t USB_OutTransferCallback(USB_FeatureRequestType FeatureType, USB_ReportType ReportType, USB_ReportID ReportID, uint8_t* pData, uint16_t* length);
int8_t USB_InTransferCallback(void);

#ifdef __cplusplus
}
#endif
#endif
