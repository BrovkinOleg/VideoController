#ifndef __DEUS_TYPES_H
#define __DEUS_TYPES_H

#pragma anon_unions
#include "stdint.h"
#include "sys_types.h"

#define POS_SENSORS_NUM				32
#define FW_FPGA_VERSION_STR_SIZE	10
#define FW_STM32_VERSION_STR_SIZE	10
#define FW_NRF52_VERSION_STR_SIZE	10
#define SERIAL_NUMBER_STR_SIZE		30
#define USB_TIMESTAMPS_NUM			10
#define USB_MAX_PACKET_SIZE			63
#define USB_MAX_DATA_SIZE			(USB_MAX_PACKET_SIZE - 3)
#define USB_FW_PART_SIZE			58
#define RADIO_MAX_PACKET_SIZE		252
#define RADIO_MAX_DATA_SIZE			(RADIO_MAX_PACKET_SIZE - 2)
#define TIMESTAMP_MAX				0xFFFF
#define TIMESTAMP_MIN				0x0

#define RAW_TIMESTAMP_MAX			55000
#define RAW_TIMESTAMP_MIN			12000
#define RAW_TIMESTAMP_MAX_VALUE		(RAW_TIMESTAMP_MAX - RAW_TIMESTAMP_MIN)

//////////////////NRF52 SPI slave commands///////////////////

#pragma pack(push,1)

typedef enum
{
	NRF52_GET_DATA = 1,
	NRF52_FW_PREPARE,
	NRF52_FW_PART_DOWNLOAD,
	NRF52_SLEEP,
	NRF52_WKUP,
	NRF52_FPGA_OFF,
	NRF52_FPGA_ON,
	NRF52_SET_RF_POWER,
	NRF52_GET_RF_POWER,
	NRF52_GET_RSSI,
} SPI_NRF52_CMD;

/////////////////��������������� ���� ������/////////////////

typedef enum
{
	//USB transmit packets
	CMD_USB_DeviceInReport_Transmitted,
	CMD_USB_ConfigReport_Transmitted,
	CMD_USB_StatusReport_Transmitted,
	CMD_USB_TimestampsTestReport_Transmitted,
	
	//USB receive packets
	CMD_USB_SetSerialNumberReport_Received,
	
	CMD_USB_FWPrepareReport_HMD_Received,
	CMD_USB_FWPrepareReport_LeftCtrl_Received,
	CMD_USB_FWPrepareReport_RightCtrl_Received,
	
	CMD_USB_FWPartReport_HMD_Received,
	CMD_USB_FWPartReport_LeftCtrl_Received,
	CMD_USB_FWPartReport_RightCtrl_Received,
	
	CMD_USB_HapticActionReport_LeftCtrl_Received,
	CMD_USB_HapticActionReport_RightCtrl_Received,
	
	CMD_USB_PowerControlReport_LeftCtrl_Received,
	CMD_USB_PowerControlReport_RightCtrl_Received,
	
	//RADIO transmt packets
	CMD_RADIO_FWPreparePacket_LeftCtrl_Transmitted,
	CMD_RADIO_FWPreparePacket_RightCtrl_Transmitted,
	CMD_RADIO_FWPreparePacket_LHOUSE1_Transmitted,
	CMD_RADIO_FWPreparePacket_LHOUSE2_Transmitted,
	
	CMD_RADIO_FWPartPacket_LeftCtrl_Transmitted,
	CMD_RADIO_FWPartPacket_RightCtrl_Transmitted,
	CMD_RADIO_FWPartPacket_LHOUSE1_Transmitted,
	CMD_RADIO_FWPartPacket_LHOUSE2_Transmitted,
	
	CMD_RADIO_HapticControlPacket_LeftCtrl_Transmitted,
	CMD_RADIO_HapticControlPacket_RightCtrl_Transmitted,
	CMD_RADIO_PowerControlPacket_LeftCtrl_Transmitted,
	CMD_RADIO_PowerControlPacket_RightCtrl_Transmitted,
	
	//RADIO receive packets
	CMD_RADIO_DeviceStatusPacket_LeftCtrl_Received,
	CMD_RADIO_DeviceStatusPacket_RightCtrl_Received,
	
	CMD_RADIOrackingPacket_LeftCtrl_Received,
	CMD_RADIOrackingPacket_RightCtrl_Received,
} LastCommandID; //1

typedef enum
{
	NormalMode = 0,
	UpdateNeeded,
	FWDownloadComplete,
	FWDownloadError,
	FWUpdateComplete
} DeviceMode;

typedef enum
{
	CMD_None = 0,
	Calibrate_IMU,
	Calibrate_POS,
	FWUpdatePrepare,
	FullReset,
} ConfigCMD; //1

typedef enum
{
	Disabled = 0,
	Enabled,
	Charging,
	LowPower
} PowerState; //1

typedef enum
{
	Normal,
	Standby,
	Reload,
	DFU
} ICPowerState; //1

typedef enum
{
	LaserX = 0,
	LaserY = 0xFF
} LaserAxis;

typedef enum
{
	NotPresent = 0,
	Working,
	InDFUMode,
	Updated,
	Erased
} ICState; //1

typedef enum
{
	Device_NotFound = 0,
	Device_Working,
	Device_CalibrationNeed,
	Device_UpdateFailed,
	Device_UpdateSucess,
	Device_Error
} DeviceStatus; //1

typedef enum
{
	STM32,
	FPGA,
	NRF52
} DeviceIC; //1

typedef enum
{
	HMD,
	CTR_LEFT,
	CTRL_RIGHT,
	LHOUSE1,
	LHOUSE2
} Device; //1

typedef enum
{
	CalibratePosition,
	CalibrateOrientation
} CalibrationType;

typedef enum
{
	InReport = 0,
	OutReport = 1,
	FeatureReport = 2
} USB_ReportType;

typedef enum
{
	USB_FeatureSet = 0,
	USB_FeatureGet
} USB_FeatureRequestType;

typedef enum
{
	STM32F072CBU6 = 1,
	NRF52832QFAAR,
	A10M04SCE144C8G,
} ICName;

typedef enum
{
	Locked = 0x43,
	Unlocked = 0x22
}LockState;

typedef struct
{
	uint8_t 		HW_Ver;
	uint8_t 		FW_Ver_Major;
	uint8_t 		FW_Ver_Minor;
	uint16_t		FW_Ver_Rev;
	DeviceMode 		Mode;
	ICState 		FPGA_State;
	ICState 		MPU_State;
	ICState 		NRF_State;
} DeviceData; //9b

typedef struct
{
	uint8_t 	Id;		//1b
	uint16_t 	Time;	//2b
} Timestamp; //3b

typedef struct
{
	float X;
	float Y;
	float Z;
} Vector3f; //12b

typedef struct
{
	float W;
	float X;
	float Y;
	float Z;
} Vector4f; //16b

typedef struct
{
	uint8_t X;
	uint8_t Y;
	uint8_t Z;
} Vector3u8; //12b

typedef struct
{
	uint16_t X;
	uint16_t Y;
	uint16_t Z;
} Vector3u16; //6

typedef struct
{
	int8_t X;
	int8_t Y;
	int8_t Z;
} Vector3i8; //12b

typedef struct
{
	int16_t X;
	int16_t Y;
	int16_t Z;
} Vector3i16; //6

typedef struct
{
	uint8_t RemapType;	//������� ����: 0 - XYZ, 1 - XZY, 2 - YXZ, 3 - YZX, 4 - ZXY, 5 - ZYX
	Vector3f Scale;	//�������������� ���� (����)
	Vector3f Bias;	//�������� �� ���� (bias)
} Calibration; //16b

typedef struct
{
    Vector3i16	Accelerometer;	//6b
	Vector3i16	Gyroscope;		//6b
	Vector3i16	Magnetometer;	//6b
} IMU_Data; //18b

typedef struct
{
    Vector3i16	Accelerometer;	//6b
	int16_t		Temperature;	//2b
	Vector3i16	Gyroscope;		//6b
	Vector3i16	Magnetometer;	//6b
} IMU_FullData; //18b

typedef struct
{
	Calibration Accelerometer;
	Calibration Gyroscope;
	Calibration Magnetometer;
} IMU_CalibrationData;

typedef struct
{
	uint8_t ActiveDiodeCount; //>=4
	uint8_t MinimumTrackedDiodeCount; //>=4, <= ActiveDiodeCount
	uint8_t LighthouseCount; //>=1
	uint8_t TrackingFrequency; //[Hz]
	uint32_t ModulationFrequency; //[Hz]
} POS_CalibrationData; //88b

typedef struct
{
	float D1x;
	float D2x;
	float D3x;
	float D4x;
	float D1y;
	float D2y;
	float D3y;
	float D4y;
} DistortionCoeffs;

typedef struct
{
	IMU_CalibrationData		IMU;
	//POS_CalibrationData	POS;
	DistortionCoeffs		LensDistortion;
	Vector4f				Tracker2Device;
	Vector4f				Display2Device;
} TrackerCalibrationData; //161

typedef struct
{
	LaserAxis	Axis; //1b
	uint16_t	Timestamp[POS_SENSORS_NUM]; //64b if 32 sensors used
} POS_Data; //65b

typedef struct
{
	uint8_t			res; //1b
	IMU_FullData	IMU; //20b
	POS_Data		POS; //65b
} Tracking_Data; //86b

typedef struct
{
	LaserAxis	Axis;				 	//1b
	uint8_t 	DiodeCount;				//1b
	Timestamp	Timestamp[USB_TIMESTAMPS_NUM];	//30b
} RawPositionData;	//44b

typedef struct
{
	uint8_t 	Duration;	//2b
	uint8_t		Power;		//1b
} Haptic_Data; //3b

typedef struct
{
	int8_t 	SensorX;	//1b
	int8_t 	SensorY;	//1b
} Touch_Data; //2b


typedef union
{
	struct
	{
		u8 wake_up : 1;
		u8 left : 1;
		u8 right : 1;
		u8 up : 1;
		u8 down : 1;
		u8 ok : 1;
		u8 top1 : 1;
		u8 volup : 1;
		u8 voldn : 1;
	};
	u16 byteword;
} Buttons_Data; //2b

typedef struct
{
	uint32_t	Version;
	uint32_t	Size;
	uint32_t	CRC32;
} FirmwareInfo; //8b

typedef struct
{
	uint32_t	BlockNumber;
	uint8_t		Data[USB_FW_PART_SIZE]; //58b
} FW_Part_Data; //63

typedef struct
{
	uint8_t	FW_FPGA[FW_FPGA_VERSION_STR_SIZE];
	uint8_t	FW_STM32[FW_STM32_VERSION_STR_SIZE];
	uint8_t	FW_NRF52[FW_NRF52_VERSION_STR_SIZE];
} FW_Ver;

typedef struct
{
	uint16_t 	BlockNumber;								 	//4b
	uint8_t 	Data[RADIO_MAX_DATA_SIZE - sizeof(uint16_t)]; 	//248b
} RADIO_FW_Part_Data; 	//250b

typedef struct
{
	uint32_t	TimestampMaxValue;
	////
} Basestation_Data;

typedef struct
{
	ICPowerState	STM32;
	ICPowerState	NRF52;
	ICPowerState	FPGA;
} DevicePower;

typedef struct
{
	ICState			State;
	ICName			ChipName;
	FirmwareInfo	CurrentFirmware;
} TargetInfo;

typedef struct
{
	uint8_t major;
	uint8_t minor;
	uint16_t revision;
} Version;

typedef struct
{
	u8 id;
	Device device;
	DeviceStatus status;
	IMU_Data raw_orient;
	i16 temperature;
	RawPositionData	raw_pos;
	Buttons_Data buttons;
	u8 stick_power;
	Touch_Data touch_data;
	u8 battery_status;
	u16 IPDres_value;
} SensorDataReport; //Report #1

#pragma pack(pop)

#endif
