#pragma once

#include "driver.h"
#include "usb_device.h"

typedef enum
{
	None = 0,
	CDC,
	HID
} USB_DeviceClass;

typedef struct
{
	USB_TypeDef* usb;
	USB_DeviceClass device_class;
	u16 VID;
	u16 PID;
	char manufacturer_string[32];
	char device_string[32];
	char serial_string[32];
	void(*usb_callback)(uint8_t report_id, uint8_t* data);
} USBConnection;

HAL_StatusTypeDef USBConnection_Init(USBConnection* usb_connection);
