
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * This notice applies to any and all portions of this file
  * that are not between comment pairs USER CODE BEGIN and
  * USER CODE END. Other portions of this file, whether 
  * inserted by the user or by software development tools
  * are owned by their respective copyright owners.
  *
  * Copyright (c) 2018 STMicroelectronics International N.V. 
  * All rights reserved.
  *
  * Redistribution and use in source and binary forms, with or without 
  * modification, are permitted, provided that the following conditions are met:
  *
  * 1. Redistribution of source code must retain the above copyright notice, 
  *    this list of conditions and the following disclaimer.
  * 2. Redistributions in binary form must reproduce the above copyright notice,
  *    this list of conditions and the following disclaimer in the documentation
  *    and/or other materials provided with the distribution.
  * 3. Neither the name of STMicroelectronics nor the names of other 
  *    contributors to this software may be used to endorse or promote products 
  *    derived from this software without specific written permission.
  * 4. This software, including modifications and/or derivative works of this 
  *    software, must execute solely and exclusively on microcontroller or
  *    microprocessor devices manufactured by or for STMicroelectronics.
  * 5. Redistribution and use of this software other than as permitted under 
  *    this license is void and will automatically terminate your rights under 
  *    this license. 
  *
  * THIS SOFTWARE IS PROVIDED BY STMICROELECTRONICS AND CONTRIBUTORS "AS IS" 
  * AND ANY EXPRESS, IMPLIED OR STATUTORY WARRANTIES, INCLUDING, BUT NOT 
  * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
  * PARTICULAR PURPOSE AND NON-INFRINGEMENT OF THIRD PARTY INTELLECTUAL PROPERTY
  * RIGHTS ARE DISCLAIMED TO THE FULLEST EXTENT PERMITTED BY LAW. IN NO EVENT 
  * SHALL STMICROELECTRONICS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
  * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
  * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF 
  * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
  * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
  * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f0xx_hal.h"
#include "i2c.h"
#include "iwdg.h"
#include "tim.h"
#include "usart.h"
#include "usb_device.h"
#include "gpio.h"

/* USER CODE BEGIN Includes */
#include "BNO080_box.h"
#include "USB2512B_box.h"
#include "sh2.h"
#include "shtp.h"
#include "nrf24_box.h"
#include "TC358870_box.h"
#include "TC358870_registers.h"
#include "box_usb_hid.h"
/* USER CODE END Includes */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
	uint8_t SOST_I2C;
	
/* Private variables ---------------------------------------------------------*/

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);

/* USER CODE BEGIN PFP */
/* Private function prototypes -----------------------------------------------*/

/* USER CODE END PFP */

/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  *
  * @retval None
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
	__disable_irq();
  /* USER CODE END 1 */

  /* MCU Configuration----------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USB_DEVICE_Init();
  MX_I2C2_Init();
  MX_USART1_UART_Init();
  MX_TIM2_Init();
  MX_IWDG_Init();
  /* USER CODE BEGIN 2 */
//-------------------------------------------------	
	__enable_irq();
	HAL_Delay(10);
	
	BoxInitUSART1();	//	Init_TX1
	BoxInitTimer2();	//	
	BoxStartIWDT();		//	Start IWDT
	BoxPausePWR();		//	#define PAUSE_PWR
	BoxInitI2C2();		//	���������� ������������� I2C2		
	BoxInitSPI1();		//	���������� ������������� SPI1

//------------------- USB_HUB2512B ----------------
//	��������� USB-HUB � "SMBus"
	SOST_I2C = USB2512B;	//	�������� � USB_HUB
	HAL_Delay(10);
	ResetUSB2512B(0,1);
//	���� ��������� ������� SMBus	
	SMBus_mode(1);			
	HAL_Delay(1);
//	����� ��� 500�� �� USB_BUS	
	InitUSB2512B();			
	HAL_Delay(10);
	
//------------------- TC358870 --------------------	
	SOST_I2C = TOSHIBA;		//	�������� � TOSHIBA_TC358870
	HAL_Delay(1);
	SMBus_mode(0);				//	�������� I2C2 �� �������	
	CHK_HDMI = 0;					//	��� �������� ����������� ������� HDMI
	BoxPowerOn_TC358870();//	TC358870 power ON 
	HAL_Delay(10);
	
	Init_Reg_TC358870();			//	������� �������� � EDID		
	
//-------------------- BNO080 ---------------------
	SOST_I2C = BNO080;		//	�������� � BNO080
	SMBus_mode(0);				//	�������� I2C2 �� �������
	BoxPausePWR();				//	#define PAUSE_PWR
	HAL_Delay(20);
	BoxStartBNO080();		
	HAL_Delay(20);
	memcpy(Temp_buf.header,"DATA",4);	
	
	if (QUAT == SH2_GYRO_INTEGRATED_RV)
		Box_Set_Future_Command(QUAT,10000);	//	100 Hz (max = 1000 Hz)	
	else
		Box_Set_Future_Command(QUAT,1000);	//	max speed
	
	Box_Set_Future_Command(SH2_ACCELEROMETER, 1000);	
	Box_Set_Future_Command(SH2_GYROSCOPE_CALIBRATED,1000);
	Box_Set_Future_Command(SH2_MAGNETIC_FIELD_CALIBRATED, 2000);
	
//------------------- nRF24L01P -------------------
	Flag_Get_nRF = 0;				//	������� �� ����
	nRF24L01P_Init(10,32);	//	chan=10d, payload=32d
	///nRF24L01P_PowerUpTx();
	nRF24L01P_PowerUpRx();
	
	memcpy(Pult_nRF_buf.header,"PULT",4);
	memset(&Pult_nRF_buf.rez[0],0,5);
	
//---------------- PCM2904_Audio_Codec ------------
	GPIOB->ODR |= (1<<15);	//	�������� ���� USB_Audio_Codec
//-------------------------------------------------
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
	USART1->TDR = 0x01;
	while (1)
  {				
		BoxResetIWDT();	//	1.6 sec ����� WDT
		//test_Dip5(); 
		
	//	��������� ��� �� BNO080	(������ ���������� ���������)		
		if ((Flag_Get_BNO != 0)||((GPIOA->IDR & (1<<2)) == 0))
		{					
			SOST_I2C = BNO080;	
			Box_Rasbor_Packet();	
			Flag_Get_BNO = 0;			
		}
		
	//	��������� BNO080 �� Glob_Flag (���� ���� ���������) 	
		if (Glob_Flag != 0)		
			Rec_BNO_buffer();
		
	//	��������� ����� �� ������ ����	
		if (Flag_Get_nRF != 0)
		{
			Flag_Get_nRF = 0;	
			Timer_pult_yes = 100;			
			Box_Get_nRF_Packet(); 						
		}
		
	//	�������� HDMI SYS_STATUS (0x8520) InputVideoSync - OK
		if (Timer_CHK_HDMI > 100)
		{
			Timer_CHK_HDMI = 0;			
			Check_HDMI();		//	�������� ������� HDMI						
		}
		
	//	������� ��� �������� ��������	
		if (mem_CHK_HDMI != CHK_HDMI)
		{		
			if (CHK_HDMI != 0)
			{	
				mem_CHK_HDMI = CHK_HDMI;	//	��������� ��������			
				BoxPausePWR();						//	����� ������ �� USB
				SOST_I2C = TOSHIBA;				
				Init_Reg_TC358870();			//	������� �������� � EDID	
				Init_Monitor_H381DLN01();	//	������� � ������� ��������� ���������
				HAL_Delay(1);
				SOST_I2C = BNO080;				
				
			}
			else
			{	
				mem_CHK_HDMI = CHK_HDMI;	//	���������� ��������
				H381DLN01_PowerOff();
				
			}			
		}		
		
  /* USER CODE END WHILE */

  /* USER CODE BEGIN 3 */

  }
  /* USER CODE END 3 */

}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{

  RCC_OscInitTypeDef RCC_OscInitStruct;
  RCC_ClkInitTypeDef RCC_ClkInitStruct;
  RCC_PeriphCLKInitTypeDef PeriphClkInit;

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_LSI|RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.LSIState = RCC_LSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL3;
  RCC_OscInitStruct.PLL.PREDIV = RCC_PREDIV_DIV1;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USB|RCC_PERIPHCLK_USART1;
  PeriphClkInit.Usart1ClockSelection = RCC_USART1CLKSOURCE_PCLK1;
  PeriphClkInit.UsbClockSelection = RCC_USBCLKSOURCE_PLL;

  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  HAL_RCC_MCOConfig(RCC_MCO, RCC_MCO1SOURCE_HSE, RCC_MCODIV_4);

    /**Configure the Systick interrupt time 
    */
  HAL_SYSTICK_Config(HAL_RCC_GetHCLKFreq()/1000);

    /**Configure the Systick 
    */
  HAL_SYSTICK_CLKSourceConfig(SYSTICK_CLKSOURCE_HCLK);

  /* SysTick_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(SysTick_IRQn, 0, 0);
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @param  file: The file name as string.
  * @param  line: The line in file as a number.
  * @retval None
  */
void _Error_Handler(char *file, int line)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  while(1) 
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
    ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/**
  * @}
  */

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
